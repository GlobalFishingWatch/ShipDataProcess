===============
ShipDataProcess
===============

ShipDataProcess provides packages and modules that help users process raw ship data. The data may come from Automatic identification system (AIS) transmission or others. Ship data includes vessel's name, callsign, shiptype information etc. You might find the packages here useful for normalizing ship names and IRCS (International Radio Call Sign) and for dealing with various types of ships and fishing gears. Typical usage often looks like this:

    #!/usr/bin/env python

    from shipdataprocess.normalize import normalize_shipname, normalize_callsign
    from shipdataprocess.shiptype import determine_shiptype, make_shiptype_dict


Contributor
-----------
This work was done based on the previous work of the team of Global Fishing Watch (GFW).

Jaeyoon Park
David Kroodsma
Andres Arana
Enrique Tuya
Bjorn Bergman